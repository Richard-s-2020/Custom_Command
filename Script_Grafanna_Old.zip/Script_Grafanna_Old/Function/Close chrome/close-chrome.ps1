function Close_Chrome {
    # Find the Notepad process
    $notepadProcess = Get-Process -Name "chrome" -ErrorAction SilentlyContinue

    foreach ($notepadProces in $notepadProcess) {
        if ($notepadProces) {
            # Close Notepad
            $notepadProces | ForEach-Object { $_.CloseMainWindow() }
        }
        else {
            Write-Host "chrome is not running."
        }
    }
    
}