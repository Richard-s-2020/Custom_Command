﻿# Define the Win32 class with GetWindowRect and SetWindowPos
#. c:\Script_Grafanna\Function\Get-WindowPosition\Get-WindowPosition.ps1
. \\nl1-pc-176\c$\Script_Grafanna\Function\Get-WindowPosition\Get-WindowPosition.ps1
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public class Win32 {
    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hwnd, out RECT lpRect);

}
"@

# Datax
$X_Locatie_Notebook = 500
$Y_Locatie_Notebook = -500

$X_Locatie_Notebook_End = -5
$Y_Locatie_Notebook_End = 189


# Functions
function mouse_event {
    #Move mouse
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($X_Mouse, $Y_Mouse);

    Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern void mouse_event(int flags, int dx, int dy, int cButtons, int info);' -Name U32 -Namespace W;
    [W.U32]::mouse_event(6, $X, $Y, 0, 0); # Left mouse click
}


function Close_Chrome {
    # Find the Notepad process
    $notepadProcess = Get-Process -Name "chrome" -ErrorAction SilentlyContinue

    foreach ($notepadProces in $notepadProcess) {
        if ($notepadProces) {
            # Close Notepad
            $notepadProces | ForEach-Object { $_.CloseMainWindow() }
        }
        else {
            Write-Host "chrome is not running."
        }
    }
    
}

# Data
$set_UP = 1
$X_Mouse = 0
$Y_Mouse = 0

#close Notepad
Close_Chrome
Start-Sleep -Seconds 2

$set_UP = 1
$data = 0
#                                                                                                  Chrome
$chromeinstalldir = "C:\Program Files\Google\Chrome\Application\chrome.exe"

# link voor de Website waar die naar toe moet gaan
$monitoringDown = 'https://grafana.denkavit.local:3000/d/RKmQKHlZz1/test-personal-dashboard?orgId=1&refresh=5m&var-IDs_Support=779,%20395,%201004,%201072&var-IDs_Infra=17,%201031,%201122,%201131,%201135,%20958&var-IDs_Application=175,%20173,%201073,%20810,%20176,%20660,%20363&var-Locations=218&var-Locations=219&var-Locations=134&var-Locations=136&var-Locations=137&var-Locations=142&var-Locations=212&var-Locations=215&var-Locations=160&var-Locations=129&var-Locations=148&var-Locations=165&kiosk'
$monitoringUp = 'https://grafana.denkavit.local:3000/d/L55BS1B7z/helpdesk-nl-it-us-json-api?orgId=1&refresh=15s&autofitpanels=true&kiosk'


$locatie_Folder = "C:\Script_Grafanna"
$Debug_Filles = $locatie_Folder + "\debug" 
$script_Filles = $locatie_Folder + "\script" 

# set-up script stop niet 
$Stop = 0

# Start Notepad
# Start chrome op de website 
Start-Process -FilePath $chromeinstalldir ('--new-window', '--start-fullscreen', '--user-data-dir=c:/screen1', '--window-position=1101,-625', $monitoringUp)
Start-Process -FilePath $chromeinstalldir ('--new-window', '--start-fullscreen', '--user-data-dir=c:/screen2', '--window-position=0,0', $monitoringDown) -ErrorVariable Test 
Start-Sleep -Seconds 1

$X_Mouse = 0
$Y_Mouse = 0
mouse_event

Start-Sleep -Seconds 1
# Move mouse to specific positions
$X_Mouse = 1036
$Y_Mouse = -476
mouse_event
Start-Sleep -Seconds 1

#write in scv script
"reload;Stop;" | Out-File -FilePath $locatie_Folder\Data.csv
"0;0;" | Out-File -FilePath $locatie_Folder\Data.csv -Append 

#make a debug function! Write-Output ""
Get-Date | Out-File -FilePath $Debug_Filles\Debug.txt -Append
"Its ready to used" | Out-File -FilePath $Debug_Filles\Debug.txt -Append
"---------------------------------------------" | Out-File -FilePath $Debug_Filles\Debug.txt -Append

try {

    while ($Stop -like 0) {	    
        $data = 0
        $Chrome_Data = Get-WindowPosition -ProcessName "chrome"
        $Left = $Chrome_Data.Left
        $Csv_Files = Import-Csv -Path $locatie_Folder\Data.csv -Delimiter ";"
        
        foreach ($testfor in $Left) {
            if ($testfor -eq 0) {
                $data = $data - 1 
            }
            if ($testfor -eq 2097) {
                $data = $data + 1
            }
        }
        if ($data -eq -2) {
            #write in scv script
            "reload;Stop;" | Out-File -FilePath $locatie_Folder\Data.csv
            "1;0;" | Out-File -FilePath $locatie_Folder\Data.csv -Append 
        }
        foreach ($Tekst in $Csv_Files ) {
            $Reload = $Tekst.reload
            $Stop = $Tekst.Stop
        
        }
        Start-Sleep -Seconds 1
        if ($Reload -like 1 ) {
            $data = 0
            Start-Sleep -s 1       
            Close_Chrome
            Start-Sleep -Seconds 1
            Start-Process -FilePath $chromeinstalldir ('--new-window', '--start-fullscreen', '--user-data-dir=c:/screen1', '--window-position=1101,-625', $monitoringUp)
            Start-Process -FilePath $chromeinstalldir ('--new-window', '--start-fullscreen', '--user-data-dir=c:/screen2', '--window-position=0,0', $monitoringDown) -ErrorVariable Test 
            Start-Sleep -Seconds 1

            # Move mouse to specific positions
            Start-Sleep -Seconds 1

            $X_Mouse = 0
            $Y_Mouse = 0
            mouse_event
            Start-Sleep -s 1
            $X_Mouse = 1036
            $Y_Mouse = -476
            mouse_event
            Start-Sleep -s 1       
            $locatie_Folder = "C:\Script_Grafanna"
            $Debug_Filles = $locatie_Folder + "\debug" 
            $script_Filles = $locatie_Folder + "\script" 
            
            #write in scv script
            "reload;Stop;" | Out-File -FilePath $locatie_Folder\Data.csv
            "0;0;" | Out-File -FilePath $locatie_Folder\Data.csv -Append 
            
            Start-Sleep -s 2
            #Info
            Get-Date | Out-File -FilePath $Debug_Filles\Info.txt -Append
            "Reload" | Out-File -FilePath $Debug_Filles\Info.txt -Append
            "---------------------------------------------" | Out-File -FilePath $Debug_Filles\Info.txt -Append
            Start-Sleep -s 2
            $data = 0
            $data
        }
    }
}
catch {
    powershell.exe $script_Filles\NEW-start-grafana-dashboards.ps1
    Write-Host "Error"
}