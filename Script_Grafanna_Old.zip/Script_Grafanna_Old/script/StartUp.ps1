﻿# Function to open a Chrome instance with a specific URL
function Open-ChromeOnMonitor {
    param (
        [string]$URL,
        [int]$MonitorIndex
    )

    # Check if the specified monitor exists
    if ($MonitorIndex -ge 0 -and $MonitorIndex -lt $monitors.Count) {
        $chromeArgs = " --new-window --window-position=0,0 --window-size=$($monitors[$MonitorIndex].Bounds.Width),$($monitors[$MonitorIndex].Bounds.Height) $URL"
        Start-Process "chrome.exe" -ArgumentList $chromeArgs
    } else {
        Write-Host "Monitor $MonitorIndex not found."
    }
}

# Check if both monitors are available
$monitors = [System.Windows.Forms.Screen]::AllScreens

if ($monitors.Count -ge 2) {
    # Assuming two monitors are available, you can change this logic if you have more monitors
    $monitor1 = $monitors[0]
    $monitor2 = $monitors[1]

    # Check if both monitors are turned on
    if ($monitor1.Bounds.Width -gt 0 -and $monitor2.Bounds.Width -gt 0) {
        # Open Chrome instances on the first and second monitors with your desired URLs
        Open-ChromeOnMonitor "https://grafana.denkavit.local:3000/d/RKmQKHlZz1/test-personal-dashboard?orgId=1&refresh=5m&var-IDs_Support=779,%20395,%201004,%201072&var-IDs_Infra=17,%201031,%201122,%201131,%201135,%20958&var-IDs_Application=175,%20173,%201073,%20810,%20176,%20660,%20363&var-Locations=218&var-Locations=219&var-Locations=134&var-Locations=136&var-Locations=137&var-Locations=142&var-Locations=212&var-Locations=215&var-Locations=160&var-Locations=129&var-Locations=148&var-Locations=165&kiosk" 0
        Open-ChromeOnMonitor "https://grafana.denkavit.local:3000/d/L55BS1B7z/helpdesk-nl-it-us-json-api?orgId=1&refresh=15s&autofitpanels=true&kiosk" 1
    } else {
        Write-Host "Please turn on both monitors and run the script again."
    }
} else {
    Write-Host "Two monitors are required for this script to work."
}
