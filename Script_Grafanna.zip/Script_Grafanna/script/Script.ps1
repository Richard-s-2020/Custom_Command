﻿#locatie of the Function
$MainFolder = "C:\Script_Grafanna"
$Function_Path = $MainFolder + "\Function\"

# Get all .ps1 files in the specified path
$scriptFiles = Get-ChildItem -Path $Function_Path -Filter *.ps1

# Dot-source each script file
foreach ($scriptFile in $scriptFiles) {
    $name = $Function_Path + "$scriptFile"
    Import-Module -Name $scriptFile
}

$chromePath = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' | Select-Object -ExpandProperty '(Default)'
$monitorn_One = Get-Monitorn -Displays 1
$monitorn_Two = Get-Monitorn -Displays 2
$monitoringDown = 'https://grafana.denkavit.local:3000/d/RKmQKHlZz1/test-personal-dashboard?orgId=1&refresh=5m&var-IDs_Support=779,%20395,%201004,%201072&var-IDs_Infra=17,%201031,%201122,%201131,%201135,%20958&var-IDs_Application=175,%20173,%201073,%20810,%20176,%20660,%20363&var-Locations=218&var-Locations=219&var-Locations=134&var-Locations=136&var-Locations=137&var-Locations=142&var-Locations=212&var-Locations=215&var-Locations=160&var-Locations=129&var-Locations=148&var-Locations=165&kiosk'
$monitoringUp = 'https://grafana.denkavit.local:3000/d/L55BS1B7z/helpdesk-nl-it-us-json-api?orgId=1&refresh=15s&autofitpanels=true&kiosk'

# MouseClick
Set-MouseClick -X $monitorn_One_X $monitorn_One_Y

#close chrome Application
Close-Application -ProcessName chrome

Start-Sleep -Seconds 2
$data = 0 

Start-Process -FilePath $chromePath -ArgumentList '--new-window', '--start-fullscreen', '--user-data-dir=c:/screen0', "--window-position=$($monitorn_One.MiddleX),$($monitorn_One.MiddleY)", $monitoringDown
Start-Process -FilePath $chromePath -ArgumentList '--new-window', '--start-fullscreen', '--user-data-dir=c:/screen1', "--window-position=$($monitorn_Two.MiddleX),$($monitorn_Two.MiddleY)", $monitoringUp

Start-Sleep -Seconds 1
Set-MouseClick -X $monitorn_One.MiddleX $monitorn_One.MiddleY

Start-Sleep -Seconds 1
Set-MouseClick -X $monitorn_Two.MiddleX $monitorn_Two.MiddleY



