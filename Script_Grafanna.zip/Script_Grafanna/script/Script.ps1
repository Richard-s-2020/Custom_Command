﻿#locatie of the Function
$MainFolder = "C:\Script_Grafanna"
$Function_Path = $MainFolder + "\Function\"

# Get all .ps1 files in the specified path
$scriptFiles = Get-ChildItem -Path $Function_Path -Filter *.ps1

# Dot-source each script file
foreach ($scriptFile in $scriptFiles) {
    $name = $scriptPath + "$scriptFile"
    Import-Module "$Function_Path$name"
}

# MouseClick
Set-MouseClick -X 0 -Y 0

#close chrome Application
Close-Application -ProcessName chrome

Start-Sleep -Seconds 2
$data = 0 

