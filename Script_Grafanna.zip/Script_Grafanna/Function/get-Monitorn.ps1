function Get-Monitorn {
    param (
        [ValidateRange(1, 20)]
        [string]$Displays
    )

    Add-Type -AssemblyName System.Windows.Forms

    # Get information for all screens
    $monitors = [System.Windows.Forms.Screen]::AllScreens
    
    # Create an array to store monitor information
    $monitorInfo = @()

    # Iterate through each monitor and display width, height, and window position
    foreach ($monitor in $monitors) {
        
        if ($Displays -eq "") {
            $width = $monitor.Bounds.Width
            $height = $monitor.Bounds.Height
            $left = $monitor.Bounds.Left
            $top = $monitor.Bounds.Top
    
            # Calculate right and bottom coordinates
            $right = $left + $width
            $bottom = $top + $height
            
            # Calculate middle coordinates
            
            $middleX = ($left + $right) / 2
            
            $middleY = ($top + $bottom) / 2

            # Remove the prefix '\\.\' from DeviceName
            $deviceName = $monitor.DeviceName

            # Create an object for each monitor
            $monitorObject = [PSCustomObject]@{
                DeviceName = $deviceName
                Width      = $width
                Height     = $height
                Left       = $left
                Top        = $top
                Right      = $right
                Bottom     = $bottom
                MiddleX    = $middleX
                MiddleY    = $middleY
            }

            # Add the monitor object to the array
            $monitorInfo += $monitorObject
        }
        elseif (!$Displays -eq "") {
            $deviceName = $monitor.DeviceName
            $Display = "\\.\DISPLAY$Displays"
            
            if ($deviceName -eq $Display) {
                $width = $monitor.Bounds.Width
                $height = $monitor.Bounds.Height
                $left = $monitor.Bounds.Left
                $top = $monitor.Bounds.Top
    
                # Calculate right and bottom coordinates
                $right = $left + $width
                $bottom = $top + $height

                # Remove the prefix '\\.\' from DeviceName
                $deviceName = $monitor.DeviceName
                
                $middleX = ($left + $right) / 2
            
                $middleY = ($top + $bottom) / 2

                # Create an object for each monitor
                $monitorObject = [PSCustomObject]@{
                    DeviceName = $deviceName
                    Width      = $width
                    Height     = $height
                    Left       = $left
                    Top        = $top
                    Right      = $right
                    Bottom     = $bottom
                    MiddleX    = $middleX
                    MiddleY    = $middleY
                }

                # Add the monitor object to the array
                $monitorInfo += $monitorObject
            }
        }
    }
    # Return the array of monitor objects
    return $monitorInfo
}