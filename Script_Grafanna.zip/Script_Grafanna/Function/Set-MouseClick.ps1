function Set-MouseClick {
    param (
        [string]$X,
        [string]$Y
    )
    #Move mouse
    $message = ""
    
    if (!($X -eq "" -or $Y -eq "")) {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($X, $Y);

        Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern void mouse_event(int flags, int dx, int dy, int cButtons, int info);' -Name U32 -Namespace W;
        [W.U32]::mouse_event(6, $X, $Y, 0, 0); # Left mouse click
        $message = "The mouse click event is used."
    }
    else {
        if ($X -eq "") {
            $message = "missing X concatenation"
        }
        elseif ($Y -eq "") {
            $message = "missing Y concatenation"
        }
    }
    if (!$message -eq "") {
        Write-Host $message
    }
}