function Close-Application {
    param (
        [string]$ProcessName
    )
    
    $message = ""

    # Find the Notepad process
    if (!$ProcessName -eq "") {
        $Application_Process = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue
        foreach ($Application_Proces in $Application_Process) {
            if ($Application_Proces.ProcessName -eq $ProcessName) {
                $Application_Proces | ForEach-Object -ErrorAction Ignore { $_.CloseMainWindow() }
                $message = "chrome has being remove"
            }
        }
        if ($notepadProcess -eq $null) {
            $message = "$ProcessName is not running."
        }
    }
    else {
        $message = "say the name of Application "
    }    
    
    if (!$message -eq "") {
        Write-Host $message
    }
}